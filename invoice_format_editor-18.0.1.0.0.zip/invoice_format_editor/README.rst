.. image:: https://img.shields.io/badge/license-AGPL--3-blue.svg
    :target: https://www.gnu.org/licenses/agpl-3.0-standalone.html
    :alt: License: AGPL-3

Invoice Format Editor
=====================
* The module assists in customizing invoice layouts in Odoo 16.

Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

License
-------
Affero General Public License v3.0 (AGPL v3)
(https://www.gnu.org/licenses/agpl-3.0-standalone.html)

Credits
-------
* Developer:
           (V14)  - Sonu@cybrosys, Dino@cybrosys,  Contact: odoo@cybrosys.com
           (V15)  - Midilaj V K,  Contact: odoo@cybrosys.com
           (V16)  - Jumana Jabin MK, Contact: odoo@cybrosys.com
           (V17)  - Ajith V, Contact: odoo@cybrosys.com
           (v18)  - Busthana, Contact: odoo@cybrosys.com

Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__

